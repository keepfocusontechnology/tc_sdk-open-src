/** Automatically generated file. DO NOT MODIFY */
package com.gavegame.tiancisdkdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}